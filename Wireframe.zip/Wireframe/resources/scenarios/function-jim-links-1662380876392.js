(function(window, undefined) {

  var jimLinks = {
    "c5e89db1-be18-44f3-9e43-b152e130b1b3" : {
      "Path_3" : [
        "ea70b2e7-2b3f-45f8-9e7b-d00d0587941d"
      ]
    },
    "cb66f7ee-4916-40bd-8ea5-34ba1c660a70" : {
      "Path_1" : [
        "ea70b2e7-2b3f-45f8-9e7b-d00d0587941d"
      ]
    },
    "32899a3f-1c08-47c0-8f4e-2330710d9715" : {
      "Path_3" : [
        "ea70b2e7-2b3f-45f8-9e7b-d00d0587941d"
      ]
    },
    "ea70b2e7-2b3f-45f8-9e7b-d00d0587941d" : {
      "Button_1" : [
        "dd19a4c0-a72f-4ed2-be9c-33b7472e349b"
      ]
    },
    "79fea18b-d1f4-4543-b5a6-185dd7757073" : {
      "Path_3" : [
        "ea70b2e7-2b3f-45f8-9e7b-d00d0587941d"
      ]
    },
    "dd19a4c0-a72f-4ed2-be9c-33b7472e349b" : {
      "Path_1" : [
        "ea70b2e7-2b3f-45f8-9e7b-d00d0587941d"
      ],
      "Category_1" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ]
    },
    "38ad3b91-49fa-4c32-aaaa-26f2a4b9605e" : {
      "Path_1" : [
        "ea70b2e7-2b3f-45f8-9e7b-d00d0587941d"
      ]
    },
    "f4a1626b-f51e-4e96-909c-48d25426ce54" : {
      "Path_37" : [
        "ea70b2e7-2b3f-45f8-9e7b-d00d0587941d"
      ]
    },
    "d12245cc-1680-458d-89dd-4f0d7fb22724" : {
      "Rectangle_2" : [
        "c5e89db1-be18-44f3-9e43-b152e130b1b3"
      ],
      "Rectangle_3" : [
        "c5e89db1-be18-44f3-9e43-b152e130b1b3"
      ],
      "Rectangle_4" : [
        "c5e89db1-be18-44f3-9e43-b152e130b1b3"
      ],
      "Path_1" : [
        "dd19a4c0-a72f-4ed2-be9c-33b7472e349b"
      ],
      "Path_2" : [
        "cb66f7ee-4916-40bd-8ea5-34ba1c660a70"
      ],
      "Path_3" : [
        "38ad3b91-49fa-4c32-aaaa-26f2a4b9605e"
      ],
      "Rectangle_7" : [
        "79fea18b-d1f4-4543-b5a6-185dd7757073"
      ],
      "Paragraph_7" : [
        "79fea18b-d1f4-4543-b5a6-185dd7757073"
      ],
      "Rectangle_8" : [
        "32899a3f-1c08-47c0-8f4e-2330710d9715"
      ],
      "Paragraph_5" : [
        "32899a3f-1c08-47c0-8f4e-2330710d9715"
      ]
    },
    "2962075a-ac9e-48f9-ac00-74b77608f074" : {
      "Path_3" : [
        "ea70b2e7-2b3f-45f8-9e7b-d00d0587941d"
      ]
    }    
  }

  window.jimLinks = jimLinks;
})(window);
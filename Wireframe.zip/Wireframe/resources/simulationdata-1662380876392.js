function initData() {
  jimData.datamasters["Games"] = [
    {
      "id": 1,
      "datamaster": "Games",
      "userdata": {
        "8a786cf6-74dc-4fc6-b0c0-3411516fb1e7": "sample text",
        "ae2dbf8b-ffb7-4c4f-8fcc-e48e211896b4": "sample text",
        "f3771406-b0ab-4a52-a9ca-be882f782170": "sample text",
        "364ddb71-8d76-49fe-bd7e-10f257b3e1cd": "sample text"
      }
    },
    {
      "id": 2,
      "datamaster": "Games",
      "userdata": {
        "8a786cf6-74dc-4fc6-b0c0-3411516fb1e7": "sample text",
        "ae2dbf8b-ffb7-4c4f-8fcc-e48e211896b4": "sample text",
        "f3771406-b0ab-4a52-a9ca-be882f782170": "sample text",
        "364ddb71-8d76-49fe-bd7e-10f257b3e1cd": "sample text"
      }
    },
    {
      "id": 3,
      "datamaster": "Games",
      "userdata": {
        "8a786cf6-74dc-4fc6-b0c0-3411516fb1e7": "sample text",
        "ae2dbf8b-ffb7-4c4f-8fcc-e48e211896b4": "sample text",
        "f3771406-b0ab-4a52-a9ca-be882f782170": "sample text",
        "364ddb71-8d76-49fe-bd7e-10f257b3e1cd": "sample text"
      }
    }
  ];

  jimData.isInitialized = true;
}
(function(window, undefined) {
  var dictionary = {
    "c5e89db1-be18-44f3-9e43-b152e130b1b3": "Play OnDeckClick - InActivePlayer (P1)",
    "cb66f7ee-4916-40bd-8ea5-34ba1c660a70": "Play - ScrollRight",
    "32899a3f-1c08-47c0-8f4e-2330710d9715": "Play On+4Click - InActivePlayer (P1)",
    "ea70b2e7-2b3f-45f8-9e7b-d00d0587941d": "Login",
    "79fea18b-d1f4-4543-b5a6-185dd7757073": "Play OnRed4Click - InActivePlayer (P1)",
    "dd19a4c0-a72f-4ed2-be9c-33b7472e349b": "Lobby",
    "38ad3b91-49fa-4c32-aaaa-26f2a4b9605e": "Play - ScrollLeft",
    "f4a1626b-f51e-4e96-909c-48d25426ce54": "Play On+4Click - ActivePlayer (P2)",
    "d12245cc-1680-458d-89dd-4f0d7fb22724": "Play",
    "2962075a-ac9e-48f9-ac00-74b77608f074": "Play OnRed4Click - ActivePlayer (P2)",
    "f39803f7-df02-4169-93eb-7547fb8c961a": "Template 1",
    "bb8abf58-f55e-472d-af05-a7d1bb0cc014": "default"
  };

  var uriRE = /^(\/#)?(screens|templates|masters|scenarios)\/(.*)(\.html)?/;
  window.lookUpURL = function(fragment) {
    var matches = uriRE.exec(fragment || "") || [],
        folder = matches[2] || "",
        canvas = matches[3] || "",
        name, url;
    if(dictionary.hasOwnProperty(canvas)) { /* search by name */
      url = folder + "/" + canvas;
    }
    return url;
  };

  window.lookUpName = function(fragment) {
    var matches = uriRE.exec(fragment || "") || [],
        folder = matches[2] || "",
        canvas = matches[3] || "",
        name, canvasName;
    if(dictionary.hasOwnProperty(canvas)) { /* search by name */
      canvasName = dictionary[canvas];
    }
    return canvasName;
  };
})(window);
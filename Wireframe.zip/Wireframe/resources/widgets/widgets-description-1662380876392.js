	window.widgets = {
		descriptionMap : widgetDescriptionMap = {},
		rootWidgetMap : widgetRootMap = {}
	};

	widgets.descriptionMap[["s-Image_1", "c5e89db1-be18-44f3-9e43-b152e130b1b3"]] = ""; 

			widgets.rootWidgetMap[["s-Image_1", "c5e89db1-be18-44f3-9e43-b152e130b1b3"]] = ["Image", "s-Image_1"]; 

	widgets.descriptionMap[["s-Image_2", "c5e89db1-be18-44f3-9e43-b152e130b1b3"]] = ""; 

			widgets.rootWidgetMap[["s-Image_2", "c5e89db1-be18-44f3-9e43-b152e130b1b3"]] = ["Image", "s-Image_2"]; 

	widgets.descriptionMap[["s-Path_1", "c5e89db1-be18-44f3-9e43-b152e130b1b3"]] = ""; 

			widgets.rootWidgetMap[["s-Path_1", "c5e89db1-be18-44f3-9e43-b152e130b1b3"]] = ["Chevron right", "s-Path_1"]; 

	widgets.descriptionMap[["s-Path_2", "c5e89db1-be18-44f3-9e43-b152e130b1b3"]] = ""; 

			widgets.rootWidgetMap[["s-Path_2", "c5e89db1-be18-44f3-9e43-b152e130b1b3"]] = ["Chevron left", "s-Path_2"]; 

	widgets.descriptionMap[["s-Path_3", "c5e89db1-be18-44f3-9e43-b152e130b1b3"]] = ""; 

			widgets.rootWidgetMap[["s-Path_3", "c5e89db1-be18-44f3-9e43-b152e130b1b3"]] = ["Multiply", "s-Path_3"]; 

	widgets.descriptionMap[["s-Image_1", "cb66f7ee-4916-40bd-8ea5-34ba1c660a70"]] = ""; 

			widgets.rootWidgetMap[["s-Image_1", "cb66f7ee-4916-40bd-8ea5-34ba1c660a70"]] = ["Image", "s-Image_1"]; 

	widgets.descriptionMap[["s-Image_2", "cb66f7ee-4916-40bd-8ea5-34ba1c660a70"]] = ""; 

			widgets.rootWidgetMap[["s-Image_2", "cb66f7ee-4916-40bd-8ea5-34ba1c660a70"]] = ["Image", "s-Image_2"]; 

	widgets.descriptionMap[["s-Path_1", "cb66f7ee-4916-40bd-8ea5-34ba1c660a70"]] = ""; 

			widgets.rootWidgetMap[["s-Path_1", "cb66f7ee-4916-40bd-8ea5-34ba1c660a70"]] = ["Multiply", "s-Path_1"]; 

	widgets.descriptionMap[["s-Path_2", "cb66f7ee-4916-40bd-8ea5-34ba1c660a70"]] = ""; 

			widgets.rootWidgetMap[["s-Path_2", "cb66f7ee-4916-40bd-8ea5-34ba1c660a70"]] = ["Chevron right", "s-Path_2"]; 

	widgets.descriptionMap[["s-Path_3", "cb66f7ee-4916-40bd-8ea5-34ba1c660a70"]] = ""; 

			widgets.rootWidgetMap[["s-Path_3", "cb66f7ee-4916-40bd-8ea5-34ba1c660a70"]] = ["Chevron left", "s-Path_3"]; 

	widgets.descriptionMap[["s-Image_1", "32899a3f-1c08-47c0-8f4e-2330710d9715"]] = ""; 

			widgets.rootWidgetMap[["s-Image_1", "32899a3f-1c08-47c0-8f4e-2330710d9715"]] = ["Image", "s-Image_1"]; 

	widgets.descriptionMap[["s-Image_2", "32899a3f-1c08-47c0-8f4e-2330710d9715"]] = ""; 

			widgets.rootWidgetMap[["s-Image_2", "32899a3f-1c08-47c0-8f4e-2330710d9715"]] = ["Image", "s-Image_2"]; 

	widgets.descriptionMap[["s-Path_1", "32899a3f-1c08-47c0-8f4e-2330710d9715"]] = ""; 

			widgets.rootWidgetMap[["s-Path_1", "32899a3f-1c08-47c0-8f4e-2330710d9715"]] = ["Chevron right", "s-Path_1"]; 

	widgets.descriptionMap[["s-Path_2", "32899a3f-1c08-47c0-8f4e-2330710d9715"]] = ""; 

			widgets.rootWidgetMap[["s-Path_2", "32899a3f-1c08-47c0-8f4e-2330710d9715"]] = ["Chevron left", "s-Path_2"]; 

	widgets.descriptionMap[["s-Path_3", "32899a3f-1c08-47c0-8f4e-2330710d9715"]] = ""; 

			widgets.rootWidgetMap[["s-Path_3", "32899a3f-1c08-47c0-8f4e-2330710d9715"]] = ["Multiply", "s-Path_3"]; 

	widgets.descriptionMap[["s-Image_1", "79fea18b-d1f4-4543-b5a6-185dd7757073"]] = ""; 

			widgets.rootWidgetMap[["s-Image_1", "79fea18b-d1f4-4543-b5a6-185dd7757073"]] = ["Image", "s-Image_1"]; 

	widgets.descriptionMap[["s-Image_2", "79fea18b-d1f4-4543-b5a6-185dd7757073"]] = ""; 

			widgets.rootWidgetMap[["s-Image_2", "79fea18b-d1f4-4543-b5a6-185dd7757073"]] = ["Image", "s-Image_2"]; 

	widgets.descriptionMap[["s-Path_1", "79fea18b-d1f4-4543-b5a6-185dd7757073"]] = ""; 

			widgets.rootWidgetMap[["s-Path_1", "79fea18b-d1f4-4543-b5a6-185dd7757073"]] = ["Chevron right", "s-Path_1"]; 

	widgets.descriptionMap[["s-Path_2", "79fea18b-d1f4-4543-b5a6-185dd7757073"]] = ""; 

			widgets.rootWidgetMap[["s-Path_2", "79fea18b-d1f4-4543-b5a6-185dd7757073"]] = ["Chevron left", "s-Path_2"]; 

	widgets.descriptionMap[["s-Path_3", "79fea18b-d1f4-4543-b5a6-185dd7757073"]] = ""; 

			widgets.rootWidgetMap[["s-Path_3", "79fea18b-d1f4-4543-b5a6-185dd7757073"]] = ["Multiply", "s-Path_3"]; 

	widgets.descriptionMap[["s-Image_1", "dd19a4c0-a72f-4ed2-be9c-33b7472e349b"]] = ""; 

			widgets.rootWidgetMap[["s-Image_1", "dd19a4c0-a72f-4ed2-be9c-33b7472e349b"]] = ["Image", "s-Image_1"]; 

	widgets.descriptionMap[["s-Path_1", "dd19a4c0-a72f-4ed2-be9c-33b7472e349b"]] = ""; 

			widgets.rootWidgetMap[["s-Path_1", "dd19a4c0-a72f-4ed2-be9c-33b7472e349b"]] = ["Multiply", "s-Path_1"]; 

	widgets.descriptionMap[["s-Image", "dd19a4c0-a72f-4ed2-be9c-33b7472e349b"]] = ""; 

			widgets.rootWidgetMap[["s-Image", "dd19a4c0-a72f-4ed2-be9c-33b7472e349b"]] = ["Image", "s-Image"]; 

	widgets.descriptionMap[["s-Image_1", "38ad3b91-49fa-4c32-aaaa-26f2a4b9605e"]] = ""; 

			widgets.rootWidgetMap[["s-Image_1", "38ad3b91-49fa-4c32-aaaa-26f2a4b9605e"]] = ["Image", "s-Image_1"]; 

	widgets.descriptionMap[["s-Image_2", "38ad3b91-49fa-4c32-aaaa-26f2a4b9605e"]] = ""; 

			widgets.rootWidgetMap[["s-Image_2", "38ad3b91-49fa-4c32-aaaa-26f2a4b9605e"]] = ["Image", "s-Image_2"]; 

	widgets.descriptionMap[["s-Path_1", "38ad3b91-49fa-4c32-aaaa-26f2a4b9605e"]] = ""; 

			widgets.rootWidgetMap[["s-Path_1", "38ad3b91-49fa-4c32-aaaa-26f2a4b9605e"]] = ["Multiply", "s-Path_1"]; 

	widgets.descriptionMap[["s-Path_2", "38ad3b91-49fa-4c32-aaaa-26f2a4b9605e"]] = ""; 

			widgets.rootWidgetMap[["s-Path_2", "38ad3b91-49fa-4c32-aaaa-26f2a4b9605e"]] = ["Chevron right", "s-Path_2"]; 

	widgets.descriptionMap[["s-Path_3", "38ad3b91-49fa-4c32-aaaa-26f2a4b9605e"]] = ""; 

			widgets.rootWidgetMap[["s-Path_3", "38ad3b91-49fa-4c32-aaaa-26f2a4b9605e"]] = ["Chevron left", "s-Path_3"]; 

	widgets.descriptionMap[["s-Image_1", "f4a1626b-f51e-4e96-909c-48d25426ce54"]] = ""; 

			widgets.rootWidgetMap[["s-Image_1", "f4a1626b-f51e-4e96-909c-48d25426ce54"]] = ["Image", "s-Image_1"]; 

	widgets.descriptionMap[["s-Image_2", "f4a1626b-f51e-4e96-909c-48d25426ce54"]] = ""; 

			widgets.rootWidgetMap[["s-Image_2", "f4a1626b-f51e-4e96-909c-48d25426ce54"]] = ["Image", "s-Image_2"]; 

	widgets.descriptionMap[["s-Path_37", "f4a1626b-f51e-4e96-909c-48d25426ce54"]] = ""; 

			widgets.rootWidgetMap[["s-Path_37", "f4a1626b-f51e-4e96-909c-48d25426ce54"]] = ["Multiply", "s-Path_37"]; 

	widgets.descriptionMap[["s-Path_18", "f4a1626b-f51e-4e96-909c-48d25426ce54"]] = ""; 

			widgets.rootWidgetMap[["s-Path_18", "f4a1626b-f51e-4e96-909c-48d25426ce54"]] = ["Chevron right", "s-Path_18"]; 

	widgets.descriptionMap[["s-Path_17", "f4a1626b-f51e-4e96-909c-48d25426ce54"]] = ""; 

			widgets.rootWidgetMap[["s-Path_17", "f4a1626b-f51e-4e96-909c-48d25426ce54"]] = ["Chevron left", "s-Path_17"]; 

	widgets.descriptionMap[["s-Image", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Image", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Image", "s-Image"]; 

	widgets.descriptionMap[["s-Image_1", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Image_1", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Image", "s-Image_1"]; 

	widgets.descriptionMap[["s-Path_1", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Path_1", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Multiply", "s-Path_1"]; 

	widgets.descriptionMap[["s-Path_2", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Path_2", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Chevron right", "s-Path_2"]; 

	widgets.descriptionMap[["s-Path_3", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Path_3", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Chevron left", "s-Path_3"]; 

	widgets.descriptionMap[["s-Image_1", "2962075a-ac9e-48f9-ac00-74b77608f074"]] = ""; 

			widgets.rootWidgetMap[["s-Image_1", "2962075a-ac9e-48f9-ac00-74b77608f074"]] = ["Image", "s-Image_1"]; 

	widgets.descriptionMap[["s-Image_2", "2962075a-ac9e-48f9-ac00-74b77608f074"]] = ""; 

			widgets.rootWidgetMap[["s-Image_2", "2962075a-ac9e-48f9-ac00-74b77608f074"]] = ["Image", "s-Image_2"]; 

	widgets.descriptionMap[["s-Path_1", "2962075a-ac9e-48f9-ac00-74b77608f074"]] = ""; 

			widgets.rootWidgetMap[["s-Path_1", "2962075a-ac9e-48f9-ac00-74b77608f074"]] = ["Chevron right", "s-Path_1"]; 

	widgets.descriptionMap[["s-Path_2", "2962075a-ac9e-48f9-ac00-74b77608f074"]] = ""; 

			widgets.rootWidgetMap[["s-Path_2", "2962075a-ac9e-48f9-ac00-74b77608f074"]] = ["Chevron left", "s-Path_2"]; 

	widgets.descriptionMap[["s-Path_3", "2962075a-ac9e-48f9-ac00-74b77608f074"]] = ""; 

			widgets.rootWidgetMap[["s-Path_3", "2962075a-ac9e-48f9-ac00-74b77608f074"]] = ["Multiply", "s-Path_3"]; 

	
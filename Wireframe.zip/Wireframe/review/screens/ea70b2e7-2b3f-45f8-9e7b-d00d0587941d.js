var content='<div class="ui-page" deviceName="iphone13promax" deviceType="mobile" deviceWidth="428" deviceHeight="926">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devMobile devIOS iphone-device canvas firer commentable non-processed" alignment="left" name="Template 1" width="428" height="926">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1662380876392.css" />\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
    <div id="s-ea70b2e7-2b3f-45f8-9e7b-d00d0587941d" class="screen growth-vertical devMobile devIOS iphone-device canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="Login" width="428" height="926">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/ea70b2e7-2b3f-45f8-9e7b-d00d0587941d-1662380876392.css" />\
      <div class="freeLayout">\
      <div id="s-Paragraph_1" class="richtext autofit firer ie-background commentable non-processed" customid="Uno"   datasizewidth="75.9px" datasizeheight="58.0px" dataX="176.0" dataY="57.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_1_0">Uno</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Input_1" class="text firer commentable non-processed" customid="Input 1"  datasizewidth="300.0px" datasizeheight="45.0px" dataX="45.0" dataY="138.0" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder="your@email.com"/></div></div>  </div></div></div>\
      <div id="s-Input_2" class="text firer commentable non-processed" customid="Input 1"  datasizewidth="300.0px" datasizeheight="45.0px" dataX="45.0" dataY="191.0" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder="Password"/></div></div>  </div></div></div>\
      <div id="s-Paragraph_2" class="richtext autofit firer ie-background commentable non-processed" customid="Forgot password"   datasizewidth="119.2px" datasizeheight="18.0px" dataX="45.0" dataY="245.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_2_0">Forgot password</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Button_1" class="button multiline manualfit firer click commentable non-processed" customid="Sign In"   datasizewidth="150.0px" datasizeheight="45.0px" dataX="120.0" dataY="304.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button_1_0">Sign In</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Button_2" class="button multiline manualfit firer commentable non-processed" customid="Create New Account"   datasizewidth="150.0px" datasizeheight="45.0px" dataX="120.0" dataY="357.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button_2_0">Create New Account</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;
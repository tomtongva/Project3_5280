var content='<div class="ui-page" deviceName="iphone13promax" deviceType="mobile" deviceWidth="428" deviceHeight="926">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devMobile devIOS iphone-device canvas firer commentable non-processed" alignment="left" name="Template 1" width="428" height="926">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1662380876392.css" />\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
    <div id="s-d12245cc-1680-458d-89dd-4f0d7fb22724" class="screen growth-vertical devMobile devIOS iphone-device canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="Play" width="428" height="926">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/d12245cc-1680-458d-89dd-4f0d7fb22724-1662380876392.css" />\
      <div class="freeLayout">\
      <div id="s-Image" class="image firer ie-background commentable non-processed" customid="Image"   datasizewidth="100.0px" datasizeheight="100.0px" dataX="45.5" dataY="80.0"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/a27f03ba-9211-47e2-afe7-d79fb25e83c3.jfif" />\
        	</div>\
        </div>\
      </div>\
\
\
      <div id="s-Image_1" class="image firer ie-background commentable non-processed" customid="Image"   datasizewidth="100.0px" datasizeheight="100.0px" dataX="282.5" dataY="80.0"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/3f79e2b1-15f9-4b76-b83d-1cbc2c78840d.jfif" />\
        	</div>\
        </div>\
      </div>\
\
      <div id="s-Rectangle_1" class="rectangle manualfit firer commentable non-processed" customid="Rectangle 1"   datasizewidth="168.5px" datasizeheight="242.1px" datasizewidthpx="168.50000000000006" datasizeheightpx="242.1212121212119" dataX="114.0" dataY="220.9" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_1_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_1" class="richtext autofit firer ie-background commentable non-processed" customid="Paragraph"   datasizewidth="1.0px" datasizeheight="1.0px" dataX="132.2" dataY="406.1" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_1_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_2" class="richtext autofit firer ie-background commentable non-processed" customid="S"   datasizewidth="48.0px" datasizeheight="82.0px" dataX="174.2" dataY="300.9" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_2_0">S</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_2" class="rectangle manualfit firer click commentable non-processed" customid="Rectangle 1"   datasizewidth="168.5px" datasizeheight="242.1px" datasizewidthpx="168.50000000000006" datasizeheightpx="242.1212121212119" dataX="142.0" dataY="501.9" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_2_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_3" class="rectangle manualfit firer click commentable non-processed" customid="Rectangle 1"   datasizewidth="168.5px" datasizeheight="242.1px" datasizewidthpx="168.50000000000006" datasizeheightpx="242.1212121212119" dataX="129.8" dataY="514.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_3_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_4" class="rectangle manualfit firer click commentable non-processed" customid="Rectangle 1"   datasizewidth="168.5px" datasizeheight="242.1px" datasizewidthpx="168.50000000000006" datasizeheightpx="242.1212121212119" dataX="106.0" dataY="524.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_4_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_5" class="rectangle manualfit firer commentable non-processed" customid="Rectangle 1"   datasizewidth="86.7px" datasizeheight="123.5px" datasizewidthpx="86.6796875" datasizeheightpx="123.45454545454515" dataX="35.6" dataY="792.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_5_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_6" class="rectangle manualfit firer commentable non-processed" customid="Rectangle 1"   datasizewidth="86.7px" datasizeheight="123.5px" datasizewidthpx="86.6796875" datasizeheightpx="123.45454545454515" dataX="120.2" dataY="792.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_6_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_3" class="richtext autofit firer ie-background commentable non-processed" customid="2"   datasizewidth="26.7px" datasizeheight="55.0px" dataX="65.6" dataY="826.2" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_3_0">2</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_4" class="richtext autofit firer ie-background commentable non-processed" customid="3"   datasizewidth="26.7px" datasizeheight="55.0px" dataX="152.2" dataY="826.2" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_4_0">3</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_1" class="path firer click commentable non-processed" customid="Multiply"   datasizewidth="14.2px" datasizeheight="25.2px" dataX="206.9" dataY="50.0"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="14.177894592285156" height="25.178932189941406" viewBox="206.91000047022146 50.0000001732198 14.177894592285156 25.178932189941406" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_1-d1224" d="M207.19235816293997 72.14918115483609 C206.82321801477713 72.80462952039358 206.80563845926565 73.97523391602351 207.20114817911428 74.66193475332221 C207.58785834604544 75.3486389776884 208.24703803354544 75.3331871757936 208.61617865854544 74.67756268272656 L213.99506869608206 65.11009112442547 L219.38276877695364 74.67756268272656 C219.76066794687551 75.3486389776884 220.41106810861868 75.3486389776884 220.7978688746099 74.66193475332221 C221.17576804453176 73.95960598661917 221.18456855112356 72.82025406273043 220.7978688746099 72.14918115483609 L215.41886821085257 62.58170959653499 L220.7978688746099 53.02984733876705 C221.18456855112356 52.358719391025964 221.18456855112356 51.203757319837216 220.7978688746099 50.51702091832986 C220.40226760202688 49.84589297058878 219.76066794687551 49.83028367005563 219.38276877695364 50.50141161779671 L213.99506869608206 60.06895430451512 L208.61617865854544 50.50141161779671 C208.24703803354544 49.84589297058878 207.57906832987112 49.814674369522486 207.20114817911428 50.51702091832986 C206.81442847543997 51.203757319837216 206.82321801477713 52.374328691559114 207.19235816293997 53.02984733876705 L212.5800677805547 62.58170959653499 L207.19235816293997 72.14918115483609 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_1-d1224" fill="#8E8E93" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_2" class="path firer click commentable non-processed" customid="Chevron right"   datasizewidth="22.0px" datasizeheight="35.6px" dataX="393.3" dataY="835.9"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="21.973697662353516" height="35.591800689697266" viewBox="393.32272052764904 835.9313730976796 21.973697662353516 35.591800689697266" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_2-d1224" d="M415.2964200973512 853.7272732715168 C415.27487049159413 853.0251068293726 414.9949871637664 852.4231531589952 414.41391843792064 851.8814625596333 L397.6701036183267 836.6135200614242 C397.1752263097856 836.1721325783651 396.59415291345744 835.9313730976796 395.88379355879295 835.9313730976796 C394.44201097387565 835.9313730976796 393.32272052764904 836.9746478533244 393.32272052764904 838.3188765859018 C393.32272052764904 838.9608931598227 393.6026038554768 839.5627793439202 394.09748116401795 840.024232021891 L409.1627269471397 853.7272732715168 L394.09748116401795 867.4302470348625 C393.6026038554768 867.8918140041139 393.32272052764904 868.4736807098117 393.32272052764904 869.1356732225968 C393.32272052764904 870.4799694414542 394.44201097387565 871.5231723568654 395.88379355879295 871.5231723568654 C396.5726056429416 871.5231723568654 397.1752263097856 871.2823464783884 397.6701036183267 870.8410950563775 L414.41391843792064 855.5529970187206 C415.01653676952344 855.031395561015 415.2964200973512 854.4294397136608 415.2964200973512 853.7272732715168 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_2-d1224" fill="#8E8E93" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_3" class="path firer click commentable non-processed" customid="Chevron left"   datasizewidth="22.0px" datasizeheight="35.6px" dataX="7.0" dataY="835.9"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="21.970001220703125" height="35.59000015258789" viewBox="7.000000000000002 835.9322727272726 21.970001220703125 35.59000015258789" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_3-d1224" d="M7.0 853.7272732714893 C7.0 854.4294042172705 7.279739063666533 855.0313296341712 7.8822345727623215 855.5529047235495 L24.623334529986735 870.8402299075885 C25.09658643562541 871.2814590231778 25.6991076281341 871.5222727272726 26.409349724084237 871.5222727272726 C27.82934826599501 871.5222727272726 28.97 870.479122548516 28.97 869.1348942873728 C28.97 868.4729352400526 28.668616823820415 867.8910979492492 28.19536491818174 867.4295543134236 L13.111062235010614 853.7272732714893 L28.19536491818174 840.0249247466865 C28.668616823820415 839.5634953963638 28.97 838.9616396391981 28.97 838.3196555209057 C28.97 836.975494742631 27.82934826599501 835.9322727272726 26.409349724084237 835.9322727272726 C25.6991076281341 835.9322727272726 25.09658643562541 836.1730200369323 24.623334529986735 836.6143852066916 L7.8822345727623215 851.8815558701983 C7.279739063666533 852.423219085674 7.0 853.025142325708 7.0 853.7272732714893 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_3-d1224" fill="#8E8E93" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_7" class="rectangle manualfit firer click commentable non-processed" customid="Rectangle 1"   datasizewidth="86.7px" datasizeheight="123.5px" datasizewidthpx="86.6796875" datasizeheightpx="123.45454545454515" dataX="206.9" dataY="792.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_7_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_6" class="richtext autofit firer ie-background commentable non-processed" customid="4"   datasizewidth="26.7px" datasizeheight="55.0px" dataX="237.0" dataY="826.2" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_6_0">4</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_7" class="richtext manualfit firer click ie-background commentable non-processed" customid="4"   datasizewidth="26.7px" datasizeheight="55.0px" dataX="237.0" dataY="826.2" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_7_0">4</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_8" class="rectangle manualfit firer click commentable non-processed" customid="Rectangle 1"   datasizewidth="86.7px" datasizeheight="123.5px" datasizewidthpx="86.6796875" datasizeheightpx="123.45454545454515" dataX="295.6" dataY="792.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_8_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_5" class="richtext autofit firer click ie-background commentable non-processed" customid="+4"   datasizewidth="54.7px" datasizeheight="55.0px" dataX="311.6" dataY="826.2" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_5_0">+4</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;
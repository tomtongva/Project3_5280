var content='<div class="ui-page" deviceName="iphone13promax" deviceType="mobile" deviceWidth="428" deviceHeight="926">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devMobile devIOS iphone-device canvas firer commentable non-processed" alignment="left" name="Template 1" width="428" height="926">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1662380876392.css" />\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
    <div id="s-dd19a4c0-a72f-4ed2-be9c-33b7472e349b" class="screen growth-vertical devMobile devIOS iphone-device canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="Lobby" width="428" height="926">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/dd19a4c0-a72f-4ed2-be9c-33b7472e349b-1662380876392.css" />\
      <div class="freeLayout">\
      <div id="s-Image_1" class="image firer ie-background commentable non-processed" customid="Image"   datasizewidth="100.0px" datasizeheight="100.0px" dataX="45.5" dataY="80.0"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/a27f03ba-9211-47e2-afe7-d79fb25e83c3.jfif" />\
        	</div>\
        </div>\
      </div>\
\
      <div id="s-Paragraph_1" class="richtext autofit firer ie-background commentable non-processed" customid="Paragraph"   datasizewidth="1.0px" datasizeheight="1.0px" dataX="132.2" dataY="406.1" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_1_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_2" class="richtext autofit firer ie-background commentable non-processed" customid="S"   datasizewidth="48.0px" datasizeheight="82.0px" dataX="174.2" dataY="300.9" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_2_0">S</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_1" class="path firer click commentable non-processed" customid="Multiply"   datasizewidth="14.2px" datasizeheight="25.2px" dataX="206.9" dataY="50.0"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="14.177894592285156" height="25.178932189941406" viewBox="206.91000047022146 50.0000001732198 14.177894592285156 25.178932189941406" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_1-dd19a" d="M207.19235816293997 72.14918115483609 C206.82321801477713 72.80462952039358 206.80563845926565 73.97523391602351 207.20114817911428 74.66193475332221 C207.58785834604544 75.3486389776884 208.24703803354544 75.3331871757936 208.61617865854544 74.67756268272656 L213.99506869608206 65.11009112442547 L219.38276877695364 74.67756268272656 C219.76066794687551 75.3486389776884 220.41106810861868 75.3486389776884 220.7978688746099 74.66193475332221 C221.17576804453176 73.95960598661917 221.18456855112356 72.82025406273043 220.7978688746099 72.14918115483609 L215.41886821085257 62.58170959653499 L220.7978688746099 53.02984733876705 C221.18456855112356 52.358719391025964 221.18456855112356 51.203757319837216 220.7978688746099 50.51702091832986 C220.40226760202688 49.84589297058878 219.76066794687551 49.83028367005563 219.38276877695364 50.50141161779671 L213.99506869608206 60.06895430451512 L208.61617865854544 50.50141161779671 C208.24703803354544 49.84589297058878 207.57906832987112 49.814674369522486 207.20114817911428 50.51702091832986 C206.81442847543997 51.203757319837216 206.82321801477713 52.374328691559114 207.19235816293997 53.02984733876705 L212.5800677805547 62.58170959653499 L207.19235816293997 72.14918115483609 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_1-dd19a" fill="#8E8E93" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_3" class="richtext autofit firer ie-background commentable non-processed" customid="Find Games"   datasizewidth="87.1px" datasizeheight="18.0px" dataX="297.0" dataY="89.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_3_0">Find Games</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Image" class="image firer click ie-background commentable non-processed" customid="Image"   datasizewidth="34.3px" datasizeheight="31.3px" dataX="254.0" dataY="82.3"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/0d0a6027-d6c9-4874-b3ad-13dc62b087d3.jpg" />\
        	</div>\
        </div>\
      </div>\
\
      <div id="s-Category_1" class="selectionlist firer click commentable hidden non-processed" customid="Category 1"    datasizewidth="330.0px" datasizeheight="517.0px" dataX="48.3" dataY="208.0"   tabindex="-1">\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="scroll">\
            <div class="paddingLayer">\
              <table style="height: 100%; width: 100%;" summary="">\
                <tbody>\
                  <tr>\
                    <td >\
                      <div class="option ">FName LName</div>\
                      <div class="option ">Tom Va</div>\
                      <div class="option ">Jared Tamulynas</div>\
                      <div class="option ">Alex Miller</div>\
                    </td>\
                  </tr>\
                </tbody>\
              </table>\
            </div>\
          </div>\
        </div>\
      </div>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;